--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Debian 14.7-1.pgdg110+1)
-- Dumped by pg_dump version 14.7 (Debian 14.7-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO admin;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bug; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.bug (
    id integer NOT NULL,
    cve_id character varying(16),
    fix_commit character varying NOT NULL,
    patch character varying,
    code character varying,
    verified boolean NOT NULL,
    created timestamp without time zone NOT NULL,
    project integer
);


ALTER TABLE public.bug OWNER TO admin;

--
-- Name: bug_id_sequence; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.bug_id_sequence
    AS integer
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bug_id_sequence OWNER TO admin;

--
-- Name: detection; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.detection (
    id integer NOT NULL,
    created timestamp without time zone NOT NULL,
    confidence double precision NOT NULL,
    bug integer,
    project integer
);


ALTER TABLE public.detection OWNER TO admin;

--
-- Name: detection_id_sequence; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.detection_id_sequence
    AS integer
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detection_id_sequence OWNER TO admin;

--
-- Name: project; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.project (
    id integer NOT NULL,
    url character varying(256) NOT NULL,
    name character varying(128) NOT NULL,
    author character varying(128) NOT NULL,
    language character varying(32),
    watch boolean NOT NULL,
    added timestamp without time zone NOT NULL,
    parent_id integer
);


ALTER TABLE public.project OWNER TO admin;

--
-- Name: project_id_sequence; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.project_id_sequence
    AS integer
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_id_sequence OWNER TO admin;

--
-- Data for Name: bug; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.bug (id, cve_id, fix_commit, patch, code, verified, created, project) FROM stdin;
\.
COPY public.bug (id, cve_id, fix_commit, patch, code, verified, created, project) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: detection; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.detection (id, created, confidence, bug, project) FROM stdin;
\.
COPY public.detection (id, created, confidence, bug, project) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.project (id, url, name, author, language, watch, added, parent_id) FROM stdin;
\.
COPY public.project (id, url, name, author, language, watch, added, parent_id) FROM '$$PATH$$/3327.dat';

--
-- Name: bug_id_sequence; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.bug_id_sequence', 113, true);


--
-- Name: detection_id_sequence; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.detection_id_sequence', 112, true);


--
-- Name: project_id_sequence; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.project_id_sequence', 105, true);


--
-- Name: bug bug_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bug
    ADD CONSTRAINT bug_pkey PRIMARY KEY (id);


--
-- Name: detection detection_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.detection
    ADD CONSTRAINT detection_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: bug bug_project_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.bug
    ADD CONSTRAINT bug_project_fkey FOREIGN KEY (project) REFERENCES public.project(id);


--
-- Name: detection detection_bug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.detection
    ADD CONSTRAINT detection_bug_fkey FOREIGN KEY (bug) REFERENCES public.bug(id);


--
-- Name: detection detection_project_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.detection
    ADD CONSTRAINT detection_project_fkey FOREIGN KEY (project) REFERENCES public.project(id);


--
-- Name: project project_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.project(id);


--
-- PostgreSQL database dump complete
--

